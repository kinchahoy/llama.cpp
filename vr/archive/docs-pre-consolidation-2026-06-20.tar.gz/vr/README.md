# vr/ — gfx906 (MI50 / MI60 / Vega 20) fork additions

Everything in this folder is **added by this fork on top of upstream llama.cpp
head**. It is kept separate so the delta vs. `origin/master` is easy to track.

The actual kernel optimizations are **in-place edits** to three upstream source
files and therefore live outside this folder (they cannot be relocated without
detaching them from the code they patch):

- `ggml/src/ggml-cuda/mmq.cu`  — Q8_0 selective rocBLAS dispatch
- `ggml/src/ggml-cuda/mmq.cuh` — Q4_K precompute+stride9, Q6_K launch bound
- `ggml/src/ggml-hip/CMakeLists.txt` — exactly-`gfx906` build gate

`vr/patches/` carries the same three changes as standalone, reviewable patches.

## Layout

| Path | Contents |
| --- | --- |
| `vr/patches/` | The 3 optimizations as `git apply`-able patches (Q8_0, Q4_K, Q6_K) |
| `vr/docs/` | `explain.md` (what each patch does + why), `whatsnext.md` (TG-focused backlog), `gfx906-optimizations.README.md` (apply order + gains), `benchmark-mi50-rtx3090.md` |
| `vr/scripts/` | Build/bench/profile tooling + `setup-therock-env.sh` (ROCm env) |
| `vr/configs/` | `server-models.ini` |
| `vr/assets/` | Long-context benchmark prompt fixtures (`pg78318.txt`, `prompt.txt`) |
| `vr/bench-results/` | Historical benchmark + profiler outputs (accepted gates and rejected experiments) |

## Conventions

- Tooling scripts resolve the repo root via `BASH_SOURCE/../..`, so run them
  from anywhere; build artifacts still land in `<repo>/build/`.
- Build for **exactly** `gfx906` (`-DCMAKE_HIP_ARCHITECTURES=gfx906`) or the
  Q4_K/Q6_K specializations silently compile out — see `vr/docs/explain.md`.
- Apply the standalone patches from the repo root, e.g.
  `git apply vr/patches/gfx906-q8-rocblas-dispatch.patch`.

## Start here

- **Picking up the work / handoff:** `vr/HANDOFF.md` — intended structure,
  workflow, conventions, and gotchas.
- New to the fork: `vr/docs/explain.md`.
- Planning work: `vr/docs/whatsnext.md` (currently focused on maximizing **token
  generation** for Q8_0 and Q4_K_M).

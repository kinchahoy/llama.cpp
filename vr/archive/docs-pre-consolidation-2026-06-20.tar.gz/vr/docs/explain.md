# gfx906 (MI50 / MI60 / Radeon VII) optimization patches — what they do and why

Status date: 2026-06-20

This document explains the three gfx906 patches carried on this branch in plain
terms: what each one changes, the hardware reason it helps, and how it is gated
so it only affects Vega 20.

The companion files are `gfx906-optimizations.README.md` (apply order and
measured gains) and `whatsnext.md` (open ideas). This file is the "why".

---

## The one fact that explains all three patches

gfx906 (Vega 20: MI50, MI60, Radeon VII) has **no matrix cores (no MFMA)**.
Every quantized matrix multiply runs on the ordinary vector ALU. The fast path
is the `V_DOT4_I32_I8` instruction (exposed as `__builtin_amdgcn_sdot4`, used by
`ggml_cuda_dp4a` in `common.cuh`), which does four INT8 multiply-accumulates per
lane per issue. There is also `v_dot2_f32_f16` for FP16 pairs.

Two consequences follow, and they drive everything below:

1. **Prompt processing (prefill)** is *compute bound* on the DP4A units. It runs
   through the **MMQ** kernels (`mmq.cuh`): weights stay quantized, the
   activations are quantized to Q8_1, and the inner loop is a wall of DP4A. The
   limiters are LDS (shared-memory) bank conflicts, VGPR pressure / register
   spills, and occupancy — *not* raw FLOPs. The Q4_K and Q6_K patches each fix
   one of those limiters.

2. **Text generation (decode)** is *memory-bandwidth bound*. With batch size 1
   there is almost no arithmetic per weight byte, so the kernel (MMVQ /
   `mul_mat_vec_q`) is gated by HBM2 read bandwidth. None of these three patches
   touch decode directly; that is where the headroom in `whatsnext.md` lives.

Because gfx906 is wave64 (64 threads per wave), with 64 CUs and ~1 TB/s HBM2,
the tile geometries and conflict patterns differ from the NVIDIA / CDNA / RDNA
paths the upstream code was tuned for. That mismatch is the opportunity.

---

## The build gate (read this first — it is a real gotcha)

All three optimizations are compiled in **only when the HIP target list is
exactly `gfx906` and nothing else**. The gate lives in
`ggml/src/ggml-hip/CMakeLists.txt`:

```cmake
if (GGML_HIP_COMPILE_TARGET_COUNT EQUAL 1 AND "gfx906" IN_LIST GGML_HIP_COMPILE_TARGETS)
    set_source_files_properties("...mmq-instance-q4_k.cu" PROPERTIES
        COMPILE_DEFINITIONS GGML_CUDA_MMQ_Q4K_GFX906_PRECOMPUTE)
    set_source_files_properties("...mmq-instance-q6_k.cu" PROPERTIES
        COMPILE_DEFINITIONS GGML_CUDA_MMQ_Q6K_GFX906_MIN_BLOCKS_1)
endif()
```

So if you build a multi-arch binary (e.g.
`-DCMAKE_HIP_ARCHITECTURES="gfx906;gfx908"` or add `gfx1100`), the Q4_K and Q6_K
specializations **silently disappear** and you are back on the generic path. The
Q8_0 patch (below) is *not* behind this gate — it is a runtime `cc` check — so it
survives multi-arch builds, but the two kernel patches do not. Always configure
with `-DCMAKE_HIP_ARCHITECTURES=gfx906` for these benefits.

---

## Patch 1 — Q8_0 selective rocBLAS dispatch

**File:** `ggml/src/ggml-cuda/mmq.cu` (`ggml_cuda_should_use_mmq`)

```cpp
if (cc == GGML_CUDA_CC_VEGA20 && type == GGML_TYPE_Q8_0 && n_experts == 0) {
    return ne11 <= 256;
}
```

### What it does
For dense Q8_0 matmuls on Vega 20, it keeps using the fused MMQ kernel only when
the batch dimension `ne11` (number of activation columns / tokens in the tile)
is ≤ 256. Above that, `should_use_mmq` returns false, and the matmul falls
through to the existing **rocBLAS** GEMM path instead.

### Why it works
Q8_0 is the heaviest quantized type here — 8.5 bits/weight, so the MMQ kernel
moves the most bytes and does the most DP4A work per tile of any quant. The
baseline benchmark shows Q8_0 prefill was the *worst* relative to the RTX 3090
(9–11× slower at n=512), the clearest sign the gfx906 MMQ Q8_0 path was leaving
performance on the table for wide batches. rocBLAS, by contrast, has a tuned
Vega 20 GEMM. For wide tiles the crossover favors rocBLAS; for narrow tiles MMQ
still wins because it avoids the dequantize-to-FP-and-launch-rocBLAS overhead.

Measured: pp512 **+21–25%**, pp2048 **+53–57%**, tg128 neutral (decode never
hits this batch size, so it is untouched). Operator-level
`m=4096,k=14336,n=512` went 8.49 → 10.80 TFLOPS on MI50-0.

### Why the conditions are exactly these
- `cc == GGML_CUDA_CC_VEGA20`: only gfx906; other AMD parts have MFMA or
  different GEMM tuning and are left alone.
- `n_experts == 0`: **MoE `MUL_MAT_ID` is deliberately excluded.** Expert
  matmuls are many small grouped GEMMs where the rocBLAS launch overhead would
  dominate, so they stay on MMQ.
- `ne11 <= 256`: the empirically located crossover. Below it, fused MMQ wins;
  above it, rocBLAS wins. This threshold is a tuning knob (see `whatsnext.md`).

---

## Patch 2 — Q4_K metadata precompute + stride9 LDS layout

**Files:** `ggml/src/ggml-cuda/mmq.cuh`, `ggml/src/ggml-hip/CMakeLists.txt`
**Define:** `GGML_CUDA_MMQ_Q4K_GFX906_PRECOMPUTE`

### Background: what Q4_K decode/multiply actually needs
A Q4_K block carries a super-block scale/min pair (`dm`, a `half2`) plus six
packed 6-bit sub-scales and sub-mins. The standard MMQ inner loop, for every
DP4A it issues, has to unpack a 6-bit scale, unpack a 6-bit min, and multiply
them by `dm` — arithmetic that is *redundant across the whole batch dimension*,
because the scale/min only depend on the weight tile, not on which activation
column you are multiplying against.

### What the patch does
Two changes that work together:

1. **Precompute at tile-load time.** In `load_tiles_q4_K`, instead of storing the
   raw packed scales into LDS and unpacking them inside the dot loop, it computes
   the final `dm * scale` and `dm * min` `half2` values **once** when the tile is
   loaded, and stores those finished products in LDS:

   ```cpp
   const half2 dm = bxi->dm * make_half2(1.0f, -1.0f);
   x_dmsc[i*row_stride + sizeof(int)*ksc + l] = dm * make_half2(sc8[l], m8[l]);
   ```

   The inner product
   (`vec_dot_q4_K_q8_1_impl_mmq_gfx906_precompute`) then just does DP4A and two
   `half2`-scaled accumulations — no scale/min unpacking, no `dm` multiply in the
   hot loop. The arithmetic moves from "once per (weight,activation) pair" to
   "once per weight tile," which is a big reduction because the batch dimension
   amortizes it.

2. **stride9 LDS layout.** The precomputed metadata is stored with a **row stride
   of 9** (`tile_x_sizes{..., mmq_y*9, 0}`) rather than the natural packed
   stride. The odd stride **staggers which LDS bank each wave's row lands in**.
   On wave64 gfx906 with the existing y128 / x64 / four-wave tile geometry, the
   packed layout caused many lanes to hit the same bank in the same cycle.

### Why it works
This patch is often described as "moving arithmetic out of the inner loop," and
it does, but the **dominant** win is the LDS bank-conflict reduction from
stride9, not the saved ALU ops. The profiler is explicit:

- Aggregate pp2048 LDS bank conflicts: **4.332B → 1.999B**.
- The dominant Q4_K shape alone: **1.783B → 0.357B**.

Because Q4_K prefill is LDS-wait bound (it spends real time stalled on shared
memory, not on the DP4A units), cutting bank conflicts in half translates almost
directly to throughput.

Measured (over the accepted precompute control), stride9 added: pp8192
**+6.62%**, pp512 +2.15%, pp2048 +2.34%, tg128 +1.72%, pp20000 ~neutral. The
full precompute+stride9 stack over stock gfx906 is roughly **+8–11% prefill**
and **+6% tg**. Correctness was re-validated: full ROCm0 `MUL_MAT` 1103/1103
pass.

### Why not the "obvious" alternatives (already tried, rejected)
- `min_blocks=1` on Q4_K: **−33.7%**. Q4_K needs occupancy to hide its LDS waits;
  cutting occupancy to gain registers is exactly wrong here. (Contrast Patch 3.)
- `y64` tile: −9.3% (more tile-launch overhead).
- stride10 / stride11: lost at pp8192 and pp20000 — 9 is the bank-friendly stride
  for this geometry, not just "any odd number."
- Forcing rocBLAS / F16 conversion for Q4_K: operator-level −30 to −34%.

---

## Patch 3 — Q6_K `__launch_bounds__(..., 1)`

**Files:** `ggml/src/ggml-cuda/mmq.cuh`, `ggml/src/ggml-hip/CMakeLists.txt`
**Define:** `GGML_CUDA_MMQ_Q6K_GFX906_MIN_BLOCKS_1`

### What it does
For the Q6_K MMQ translation unit only, it sets the minimum-blocks-per-CU
argument of `__launch_bounds__` to 1:

```cpp
#if defined(GGML_CUDA_MMQ_Q6K_GFX906_MIN_BLOCKS_1)
    __launch_bounds__(warp_size*nwarps, 1)   // was ", 2" for GCN/CDNA/RDNA
```

The second argument tells the compiler how many thread blocks it must keep
resident per CU. Lowering it from 2 to 1 **lets the register allocator use up to
twice as many VGPRs per thread**, at the cost of running fewer blocks
concurrently per CU (lower occupancy).

### Why it works — and why it is the opposite of Patch 2
This is the most instructive pair in the whole set. Q4_K and Q6_K are adjacent
quant types, yet they want **opposite** tuning, because they are bound by
different resources:

| Quant | Bottleneck | Right move |
| --- | --- | --- |
| Q4_K | LDS bank conflicts / LDS wait | **Keep** occupancy (Patch 2); never `min_blocks=1` |
| Q6_K | VALU + **register spills** (52 B/thread scratch) | **Drop** occupancy to gain VGPRs (Patch 3) |

Q6_K profiling showed low LDS wait but heavy VALU pressure and 52 bytes/thread of
scratch spilling to memory. Giving each thread more registers removes those
spills; the extra VGPRs are worth more than the occupancy you give up because the
kernel was not latency/occupancy starved — it was spilling. The same
`min_blocks=1` change applied to Q4_K is a −34% disaster precisely because Q4_K
*was* occupancy-sensitive.

Measured: pp8192 **+4.00%** median over six alternating runs (+4.14% steady
state).

### Rejected alternative
- Porting the Q4_K metadata-precompute trick to Q6_K: **−5.3%**. Wrong
  bottleneck — Q6_K is not LDS-bound, so trading anything for LDS behavior loses.
  (Do not reopen this; it is in the reject list.)

---

## Summary table

| Patch | Path | Hardware bottleneck attacked | Mechanism | Net |
| --- | --- | --- | --- | --- |
| Q8_0 rocBLAS dispatch | prefill, dense | gfx906 MMQ weak on wide Q8_0 | route `ne11>256` to rocBLAS | pp512 +21–25%, pp2048 +53–57% |
| Q4_K precompute + stride9 | prefill, fused MMQ | LDS bank conflicts (wave64 geometry) | precompute `dm*scale`/`dm*min`; odd LDS stride | pp ~+8–11%, tg +6% |
| Q6_K min_blocks=1 | prefill, fused MMQ | VGPR spills (52 B/thread) | trade occupancy for registers | pp8192 +4% |

All three target **prefill / prompt processing** (the DP4A-compute-bound side).
The decode / text-generation side is still wide open — see `whatsnext.md`.

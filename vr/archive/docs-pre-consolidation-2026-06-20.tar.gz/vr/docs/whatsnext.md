# MI50 / MI60 / gfx906 — next steps

Date: 2026-06-20

**Current focus: maximize token generation (TG / decode) for Q8_0 and Q4_K_M.**
Prefill is parked — the three accepted prefill patches (§7) are good enough for
now. Everything in §2–§5 is about decode throughput on those two model types.

How to use this file: each item is a **hypothesis with a test plan**, ordered by
expected value, not a predicted win. Promote to a patch only after a correctness
gate (`test-backend-ops -o MUL_MAT`) **and** an end-to-end TG gate (`llama-bench`
tg128 + long-context tg). The "Do Not Reopen" table (§9) lists dead ends — check
it first. Priority tags (HIGH/MED/LOW) reflect **our** roofline expectation, not
a measured result. A `[fork]` tag means the iacopPBK fork (§8) ships code for it
— a design lead, **speedup unverified on our tree**, not a proven win.

---

## 1. What "Q8_0" and "Q4_K_M" actually read at decode time

This determines which kernels matter. TG is memory bound (§2), so the cost is the
weight bytes streamed per token, per weight type.

- **Q8_0 model**: essentially all weights are **Q8_0** (output/embed may be Q8_0
  or F16). One kernel to win: **Q8_0 MMVQ**.
- **Q4_K_M model**: a *mix*. The bulk is **Q4_K**, but the standard Q4_K_M recipe
  promotes a minority of tensors to **Q6_K** (commonly `output.weight`, and
  `ffn_down` / `attn_v` on a subset of layers). So to fully maximize Q4_K_M TG
  you need fast **Q4_K MMVQ** *and* **Q6_K MMVQ** — Q4_K alone leaves the Q6_K
  tensors on the slow path.

Confirm the exact split for your model with
`llama-bench`/`gguf-dump` (per-tensor types) before sizing the work; the Q6_K
share is small but non-trivial and it caps the achievable Q4_K_M gain.

---

## 2. The TG target: how far from the bandwidth roofline

Decode at batch 1 streams the weight matrix once (kernel = MMVQ /
`mul_mat_vec_q`). Achieved bandwidth reconstructed from `benchmark-mi50-rtx3090.md`
(MI50-0, `m=4096,k=14336`) against the ~1024 GB/s HBM2 peak:

| Weight type | weight read | achieved BW | % of 1024 GB/s | relevant to |
| --- | ---: | ---: | ---: | --- |
| **Q4_K** | 33.0 MB | 482 GB/s | **47%** | Q4_K_M (bulk) |
| **Q6_K** | 48.2 MB | 492 GB/s | **48%** | Q4_K_M (minority) |
| **Q8_0** | 62.4 MB | 617 GB/s | **60%** | Q8_0 |

Read this as the ceiling on each model's TG: a Q4_K MMVQ that reached, say, 85%
of peak instead of 47% would be **~1.8× the weight-streaming rate** for the Q4_K
portion of a Q4_K_M model. Q8_0 is closer to the wall (60%) so its upside is
smaller (~1.4×) but still real. The lighter quant having *worse* utilization
(Q4_K 47% < Q8_0 60%) is the signature of a kernel limited by per-block dequant
overhead / occupancy / load width, **not** by the memory system — i.e. there is
kernel headroom, not just clock headroom. (Caveat: these are op-level numbers at
one shape; re-measure on your real models with `rocprof` before/after.)

---

## 3. Free TG wins first (no kernel code)

Do these before touching kernels — they can move TG more than a micro-opt and
they tell you how much of the §2 gap is clock vs kernel.

1. **HBM2 memory clock under the power cap.** TG is bandwidth bound, so if the
   225 W (MI50-0) / 178 W (MI50-1) caps throttle `mclk`, that *is* the TG ceiling
   and part of the §2 gap is clock, not kernel. Check
   `rocm-smi --showclocks --showpower` under a live decode load; try
   `rocm-smi --setperflevel high` and raise the MI50-1 cap with
   `--setpoweroverdrive`. The iacopPBK fork's power-sweep curves (§8) show TG
   (tg128) rising from ~225 W → ~300 W, i.e. these cards are power/clock-gated at
   stock caps. **Measure mclk first** so you don't credit a kernel change for a
   clock change.
2. **Dual-GPU split mode for a single stream.** `--split-mode layer` runs the two
   GPUs *sequentially* per token, so aggregate bandwidth does **not** add —
   single-stream TG is capped by one card's BW no matter that you have two.
   `--split-mode row` splits each matmul so BW *can* add, but syncs every layer;
   MI50-1 is on chipset PCIe at 178 W (no xGMI implied), so row-split may be
   comms-bound and the weaker card will drag it. Benchmark both on the real rig.
3. **Run TG-favorable flags.** Confirm `-fa` (see §5.2), and for Q4_K_M make sure
   you are actually loading a Q4_K_M (not Q4_K_S) build if you expect the Q6_K
   tensors.

---

## 4. Main TG work: faster MMVQ for Q8_0 and Q4_K (+Q6_K)

This is the core of the focus. The decode kernel is `mul_mat_vec_q` (MMVQ). The
shared techniques (apply to all three quants):

- **Warp-cooperative tiling** + **DPP-based cross-lane reductions** (GCN
  `v_*_dpp` instead of LDS/shuffle), and **wide vectorized weight loads** (aim for
  fully-coalesced 128-bit loads) to push toward HBM2 peak.
- **Occupancy/rows-per-block tuning for wave64** — the stock MMVQ tile counts are
  tuned for 32-wide warps; gfx906 is wave64.
- **Fold the activation Q8 quantization into the preceding op** (fused norm→Q8
  dispatch + a cross-op Q8 cache) to remove a full-tensor read/write round-trip
  on the bandwidth-bound path.

### 4.1 Q8_0 MMVQ (HIGH) [fork — direct template]
The fork ships `matmul/mmvq-q8_0.cuh` (warp-cooperative Q8_0 MMVQ) plus the
DPP-based Q8_1 epilogue (`quantize/epilogue.cuh`) and a "fast Q8_0 load path
using memcpy". This is the **lowest-risk** item: a near-complete reference for the
exact kernel we need. Plan: port behind the exactly-gfx906 gate, measure BW with
`rocprof` (Q8_0 starts at 60% → target >85%), gate on tg128 + long-context tg.

### 4.2 Q4_K MMVQ (HIGH) [no fork template — port the technique]
**The fork did *not* do Q4_K MMVQ** — its warp-cooperative kernels are Q4_0 /
Q4_1 / Q8_0 only. So this is original work: apply the §4 techniques (and the
lessons from our accepted Q4_K *prefill* patch — precomputing `dm*scale`/`dm*min`
to kill per-block unpack, watching LDS bank conflicts) to the Q4_K **decode**
path. Q4_K has the biggest headroom (47%) and is the bulk of Q4_K_M, so this is
the single highest-value TG item — and the one with the most uncertainty. Plan:
template off the fork's Q4_0 MMVQ structure, add Q4_K super-block scale/min
handling, gate on full ROCm0 `MUL_MAT` Q4_K correctness, then tg128.

### 4.3 Q6_K MMVQ (MED) [needed to finish Q4_K_M]
Q4_K_M reads Q6_K for `output` + some `ffn_down`/`attn_v` (§1). Without a fast
Q6_K MMVQ, those tensors cap the Q4_K_M TG gain. Lower priority than 4.2 because
it is a minority of bytes, but required for the *full* Q4_K_M win. Note: this is
the **decode** path — unrelated to the rejected Q6_K *prefill* precompute (§9).
Plan: same technique port; size the expected gain from the actual Q6_K byte share
in your model first (it may be small enough to defer).

---

## 5. Cross-cutting TG levers (quant-agnostic, help both models)

1. **Quantized KV cache (`-ctk`/`-ctv q8_0`) (HIGH — config + quality check).**
   At long context the KV read joins the per-token bandwidth budget; halving KV
   bytes raises sustained TG where attention dominates — and it is independent of
   weight quant, so it helps Q8_0 and Q4_K_M equally. Test tg at 8k/20k with f16
   vs q8_0 KV and confirm quality is acceptable.
2. **gfx906 Q8 FlashAttention (MED) [fork].** Stock `fattn*.cu` has no
   gfx906-specific path, so `-fa` uses a generic kernel. The fork ships a Q8
   flash-attention kernel (`attention/fattn-q8.cuh`) + an optimized RoPE kernel
   (`rope.cuh`). Direct long-context TG lever. Plan: evaluate, gate on tg at
   8k/20k + attention-output correctness. Pairs with KV quant.
3. **Speculative decoding (HIGH — model/config, not a kernel).** The biggest
   decode multiplier on bandwidth-bound hardware: a small draft model lets one
   weight-streaming pass verify several tokens, raising effective TG without
   raising traffic per accepted token. Works for both Q8_0 and Q4_K_M base
   models. Validate real acceptance with `llama-server` (note: `llama-bench` only
   measures the base-model path, not speculative acceptance).

---

## 6. Suggested order of attack

1. §3.1 measure/raise mclk, §3.2 pick split mode — establishes the real ceiling.
2. §4.1 Q8_0 MMVQ — lowest risk, has a fork template, immediately helps Q8_0.
3. §5.1 KV-quant + §5.3 spec decode — config-level, help both models now.
4. §4.2 Q4_K MMVQ — highest value, most original work; do once the Q8_0 port has
   proven the technique/gates on our tree.
5. §4.3 Q6_K MMVQ — finishes Q4_K_M, only if its byte share justifies it.
6. §5.2 gfx906 FA — long-context polish.

---

## 7. Parked: prefill (accepted, not reopening now)

Accepted and shipped (details in `explain.md`):

| Quant | Accepted prefill change | Gate |
| --- | --- | --- |
| Q8_0 | selective rocBLAS dispatch for dense `ne11 > 256` | pp512 +21–25%, pp2048 +53–57% |
| Q4_K | DP4A metadata precompute + stride9 LDS layout | pp ~+8–11% (tg +6% bonus) |
| Q6_K | gfx906-only `__launch_bounds__(..., 1)` | pp8192 +4.0% median |

Prefill backlog, deferred until TG is exhausted (kept for reference): port the
Q4_K precompute+stride mechanism to Q5_K/Q3_K/Q2_K; software-pipelined/prefetched
Q8_0 MMQ (`mmq-prefetch.cuh`); tune the `ne11 <= 256` Q8_0 rocBLAS crossover;
hipBLASLt for the F16/Q8_0 GEMM fallback; half-warp MoE dispatch. The
Q4_K/Q6_K kernel gates only compile in when the HIP target is *exactly* `gfx906`
— see `explain.md` for the build gotcha (it bites multi-arch builds).

---

## 8. External reference: iacopPBK/llama.cpp-gfx906

<https://github.com/iacopPBK/llama.cpp-gfx906> — sibling gfx906 fork (llama.cpp
build 7924, ROCm 7.1.1+). Mechanism names below are quoted from its README
changelog (verified by reading the repo); its **measured speedups are published
only as SVG charts** and are **not independently verified on our tree**. Treat as
a port-and-revalidate reference, not a drop-in or a source of citable numbers.
TG-relevant map (prefill/MoE/MXFP4 items omitted — see §7):

| iacopPBK technique (verified file) | Our item | Covers |
| --- | --- | --- |
| Warp-cooperative **Q8_0** MMVQ (`mmvq-q8_0.cuh`) + DPP Q8_1 epilogue (`epilogue.cuh`) | §4.1 | Q8_0 TG — direct template |
| Warp-cooperative Q4_0/Q4_1 MMVQ (`mmvq-q4_0/q4_1.cuh`) | §4.2 | Q4_K TG — *structure only*, no Q4_K |
| DPP warp reductions (`gfx906-common.cuh`) | §4 shared | wave64 cross-lane reduce |
| Fused norm→Q8 (`norm-fused-q8`), Q8 cross-op cache (`q8-cache.cuh`) | §4 shared | activation-quant round-trip |
| Q8 FlashAttention (`fattn-q8.cuh`) + RoPE (`rope.cuh`) | §5.2 | long-ctx TG |
| UPP powerplay overclock script + power-sweep curves | §3.1 | TG power-gated |

**There is no Q4_K or Q6_K MMVQ in the fork** — §4.2 and §4.3 are original work,
templated off its Q4_0/Q8_0 kernels. The unifying technique to internalize: **DPP
cross-lane ops for wave64 warp reductions** (`gfx906-common.cuh`), replacing
LDS/shuffle — but profile it on our tree before trusting it.

Community resources linked from the fork: `skyne98/wiki-gfx906`,
`skyne98/llama-labs-gfx906`.

Note: gfx906 is **Vega 20 / GCN5** (MI50/MI60/Radeon VII), *not* RDNA — ignore
any summary that calls it RX 5700-class; that is gfx1010.

---

## 9. Do Not Reopen Without New Evidence

| Idea | Reason |
| --- | --- |
| Q4_K `min_blocks=1` (prefill) | pp8192 -33.74%; Q4_K prefill is LDS-wait bound, needs occupancy |
| Q4_K y64 (prefill) | pp8192 -9.27%; more tile-launch work dominated |
| Q4_K forced rocBLAS / F16 conversion | operator-level -30% to -34% |
| Q4_K stride10 / stride11 (prefill) | quick tests lost at both pp8192 and pp20000 |
| Q4_K group2pad1 (prefill) | LDS bank conflicts returned to the pre-stride level |
| Q6_K metadata precompute (**prefill**) | pp8192 -5.3%; wrong bottleneck. Does **not** apply to the §4.3 Q6_K *decode* MMVQ idea |

---

## 10. Validation / housekeeping (carried over)

1. Direct Q6_K scratch-memory trace to confirm the 52 B/thread spill removal from
   the accepted prefill `min_blocks=1`.
2. Validate the full accepted patch set on the dual-MI50 rig after preserving the
   single-GPU gates (overlaps the §3.2 split-mode benchmark).

---

## 11. Useful Commands

Build exact gfx906 HIP:

```bash
source vr/scripts/setup-therock-env.sh
CCACHE_DISABLE=1 cmake -S . -B build/gfx906-final \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_HIP_ARCHITECTURES=gfx906 \
  -DGGML_HIP=ON \
  -DGGML_HIP_GRAPHS=ON \
  -DGGML_HIP_NO_VMM=ON \
  -DLLAMA_BUILD_TESTS=ON \
  -DLLAMA_BUILD_SERVER=ON \
  -DLLAMA_BUILD_EXAMPLES=ON \
  -DLLAMA_BUILD_TOOLS=ON \
  -DGGML_VULKAN=ON \
  -DBUILD_SHARED_LIBS=ON
CCACHE_DISABLE=1 cmake --build build/gfx906-final -j --target llama-bench test-backend-ops
```

Correctness:

```bash
source vr/scripts/setup-therock-env.sh
build/gfx906-final/bin/test-backend-ops -b ROCm0 -o MUL_MAT
```

TG measurement (per quant), e.g.:

```bash
build/gfx906-final/bin/llama-bench -m <model.gguf> -p 0 -n 128,256 -fa 0,1
# long-context TG:
build/gfx906-final/bin/llama-bench -m <model.gguf> -p 0 -n 128 -ctk q8_0 -ctv q8_0
```

# vr/ — handoff & intended structure

Last updated: 2026-06-20

This is the orientation doc for anyone (human or agent) picking up the gfx906
optimization work. `README.md` is the quick index; **this file is the "how it
all fits together and how to keep it that way."**

---

## 1. What this is

A private llama.cpp branch that speeds up inference on **AMD Vega 20 / gfx906**
(MI50, MI60, Radeon VII). The hardware reality that drives every decision:
gfx906 has **no matrix cores (no MFMA)** — quantized matmul runs on the vector
ALU via `V_DOT4` (INT8 DP4A). Therefore:

- **Prompt processing (PP / prefill)** is DP4A-**compute**-bound → kernel = MMQ.
- **Token generation (TG / decode)** is HBM2-**bandwidth**-bound → kernel = MMVQ.

The three shipped patches all target PP. The current focus (`docs/whatsnext.md`)
is TG. Full rationale in `docs/explain.md`.

---

## 2. Mental model: two kinds of "our changes"

| Kind | Where it lives | Why |
| --- | --- | --- |
| **In-place edits** to upstream files | `ggml/src/ggml-cuda/mmq.cu`, `mmq.cuh`, `ggml/src/ggml-hip/CMakeLists.txt` (NOT under `vr/`) | They are diffs against upstream source; they cannot be relocated without detaching them from the code they patch. |
| **Everything else we added** | `vr/` | Patches, docs, tooling, results, fixtures — additive files with no upstream counterpart. |

`vr/patches/` holds the **same three in-place changes** as standalone,
`git apply`-able patches, so the optimizations are reviewable and portable
independent of branch state. If you edit the in-place source, regenerate the
matching patch (see §7).

**Invariant to preserve:** the diff between this branch and `origin/master`
should be *exactly* the three source edits plus the `vr/` tree — nothing else in
upstream files. Keep new work additive under `vr/` or as a clearly-scoped source
edit with a matching patch.

---

## 3. Intended directory structure

```
vr/
├── README.md            index / start-here
├── HANDOFF.md           this file
├── patches/             the optimizations as standalone git-apply patches
│                        naming: gfx906-<quant>-<technique>.patch
├── docs/
│   ├── explain.md                      what each patch does + WHY (hardware-level)
│   ├── whatsnext.md                    prioritized backlog (currently TG-focused)
│   ├── gfx906-optimizations.README.md  apply order + measured gains
│   └── benchmark-mi50-rtx3090.md       op-level MI50 vs RTX3090 baseline
├── scripts/             build / bench / profile tooling + setup-therock-env.sh
├── configs/             server-models.ini (llama-server model presets)
├── assets/              long-context benchmark prompt fixtures
└── bench-results/       all historical benchmark + profiler output
    ├── gfx906-head-2026-06-20/         head vs head+patches baseline (Q8_0, Q4_K_M)
    ├── gfx906-qwen36/                  Qwen3.6 quick/long A/B gates
    ├── gfx906-q4k-experiments/         accepted + rejected Q4_K runs
    ├── gfx906-q6k-experiments/         accepted + rejected Q6_K runs
    └── gfx906-q4k-profile*/            rocprof counter/trace dumps
```

### Conventions
- **New optimization** → in-place source edit + `vr/patches/gfx906-<quant>-<technique>.patch` + a row in `docs/gfx906-optimizations.README.md` + a section in `docs/explain.md`.
- **New experiment results** → `vr/bench-results/gfx906-<area>-<date-or-tag>/` with `control*`/`candidate*` jsonl + a `report.md`/`comparison.txt`. Keep rejected runs too — they are the evidence behind the "Do Not Reopen" table in `whatsnext.md`.
- **Build artifacts** (`<repo>/build/...`) are NOT under `vr/` and are gitignored; never commit them.

---

## 4. The three shipped optimizations (one line each)

| Patch | File touched | Bottleneck attacked | Side |
| --- | --- | --- | --- |
| `gfx906-q8-rocblas-dispatch.patch` | `mmq.cu` | wide Q8_0 MMQ weak on gfx906 → route `ne11>256` to rocBLAS | PP |
| `gfx906-q4k-metadata-precompute.patch` | `mmq.cuh`, HIP `CMakeLists` | Q4_K LDS bank conflicts (precompute `dm*scale/min`, stride9) | PP |
| `gfx906-q6k-min-blocks-1.patch` | `mmq.cuh`, HIP `CMakeLists` | Q6_K VGPR spills (trade occupancy for registers) | PP |

Read `docs/explain.md` before changing any of these — Q4_K and Q6_K want
*opposite* occupancy tuning, which is the easiest thing to get wrong.

---

## 5. Build & run workflow

```bash
# 1. ROCm toolchain (sets CC/CXX/LD_LIBRARY_PATH from the TheRock venv)
source vr/scripts/setup-therock-env.sh

# 2. Configure for EXACTLY gfx906 (critical — see gotcha below)
cmake -S . -B build/gfx906 \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_HIP_ARCHITECTURES=gfx906 \
  -DGGML_HIP=ON -DGGML_HIP_GRAPHS=ON -DGGML_HIP_NO_VMM=ON -DBUILD_SHARED_LIBS=ON
cmake --build build/gfx906 -j --target llama-bench test-backend-ops

# 3. Correctness gate
build/gfx906/bin/test-backend-ops -b ROCm0 -o MUL_MAT
```

### A/B methodology (head vs head+patches)
- **control** = clean `origin/master` (build it from a detached worktree, no patches).
- **candidate** = this branch (= head + the three patches).
- `vr/scripts/build-gfx906-comparison.sh` automates both. For a *truly clean*
  control pass `CONTROL_PATCH=""` (its default applies the Q8 patch — that was
  for an older incremental A/B, not a clean-vs-all comparison).

---

## 6. Benchmarking conventions

- **Use `-d` (n-depth), not `-pg`.** `-p N -d D` → clean `ppN @ dD`; `-n M -d D`
  → clean `tgM @ dD`. `-pg pp,tg` reports a **blended** pp+tg number — do not use
  it when you need PP and TG separated.
- **Dual vs single GPU matters for TG.** `-sm layer` across two GPUs serializes a
  single decode stream, so dual-GPU TG *understates* kernel bandwidth. Measure
  TG **single-GPU** (`-sm none -dev ROCm0`) where the model fits (Q4_K_M does;
  Q8_0 at 29 GB does not at long context) to get the clean kernel baseline, and
  dual for the real-deployment number.
- **Memory clock check.** TG is bandwidth-bound; capture `rocm-smi --showclocks
  --showpower` mid-run so a power-cap throttle isn't mistaken for a kernel limit.
- The standing baseline is `bench-results/gfx906-head-2026-06-20/` — Qwen3.6-27B
  MTP, Q8_0 + Q4_K_M, PP and TG at depth 0/8192/16384. Note: under llama-bench an
  MTP model runs the **base path only** (no speculative acceptance); fine for A/B.

### Reps and warmup policy (default: fast)
- **`REPS=1` by default** (`vr/scripts/bench-head.sh`). One sample is enough to
  triage a change quickly; re-run only the configs that look interesting or noisy
  at higher reps, e.g. `REPS=5 vr/scripts/bench-head.sh q4_k_m_dual`. Don't pay
  for high reps on every cell.
- **Keep the warmup run on** (`WARMUP=1`, the default). Warmup absorbs one-time
  costs — HIP-graph capture, rocBLAS init, weight page-in, the `-d` KV prefill,
  and the initial clock ramp — so the timed sample is steady-state. This matters
  *most* at `REPS=1`: without warmup the single sample is polluted by those
  one-offs and the ~5-10% kernel deltas we hunt get buried. Only set `WARMUP=0`
  to deliberately measure cold-start latency.
- Net: `REPS=1` + warmup-on is the right speed/quality point — warmup does the
  variance reduction that extra reps would otherwise pay for. (The older
  `bench-gfx906-qwen36.sh` used `-r 1 --no-warmup`, which is noisier; prefer
  `bench-head.sh`.)

### Matrix and ordering (thermal-bias control)
- **Lean, high-context-weighted matrix** (TG is the priority). Per config:
  `pp512`, `pp8192` (PP: one short ref + 8K), and `tg128 @ d0 / d8192 / d16384`
  (TG: short ref + the two high-context depths). Tunable: `PROMPTS=512,8192,16384`
  to add high PP, `DEPTHS="8192 16384 32768"` for deeper TG (watch VRAM).
- **Control and candidate are interleaved per test**, not all-control-then-all-
  candidate. The cards heat-soak / power-cap-drift over a long run; interleaving
  makes both builds see near-identical state so the *delta* stays unbiased for
  free. This is more important (and cheaper) than inserting cooldowns.
- Inter-run gap options (default off; interleaving already protects the A/B):
  - `COOLDOWN=30` — fixed idle seconds between runs.
  - `COOL_TEMP=60` — **wait until the hottest GPU cools to this temp** before each
    run (overrides COOLDOWN). `COOL_SENSOR=edge|junction|memory` (default `edge` —
    junction idles ~40 °C so a 60 °C junction target is near-unreachable),
    `COOL_TIMEOUT=300` caps the wait so it never hangs. This is the more principled
    gate: under load these cards hit ~99 °C junction (at the MI50 throttle ceiling),
    so cooling to a fixed temp makes every run start from the same thermal state.
  - `RANDOMIZE=1` shuffles test order.
  Note gfx906 is **power-capped** (225 W/178 W), so clocks are limited by the power
  cap as much as by temperature; the temp gate addresses the thermal component.

---

## 7. Script reference (`vr/scripts/`)

| Script | Purpose |
| --- | --- |
| `setup-therock-env.sh` | Source it first — exports CC/CXX/ROCm runtime paths from the TheRock venv. No-op-safe to re-source. |
| `build-gfx906-comparison.sh` | Builds clean-mainline control + current-tree candidate into `build/`. |
| `bench-head.sh` | **Primary** head-vs-head+patches bench (Q8_0 + Q4_K_M, PP/TG at depth). `REPS=1` default; filter to one config + raise `REPS` to confirm. |
| `watch-bench.sh` + `_bench_table.py` | Live dashboard / parser for a bench run — auto-follows the current `.err` and prints the control-vs-candidate t/s table. |
| `bench-gfx906-qwen36.sh` | Qwen3.6 quick/long A/B harness (control vs candidate), writes `bench-results/gfx906-qwen36/`. |
| `run-gfx906-q4k-experiment.sh` | Q4_K experiment driver with `core`/`long`/`short` stages → `bench-results/gfx906-q4k-experiments/`. |
| `bench-q6k-min-blocks-1.sh` | Q6_K launch-bound experiment A/B → `bench-results/gfx906-q6k-experiments/`. |
| `bench-gfx906-rocm-vulkan.sh` | ROCm-vs-Vulkan backend comparison. |
| `profile-gfx906-q4k-shapes.sh` | rocprof counter/trace capture for the dominant Q4_K shapes. |
| `analyze-gfx906-q4k-profile.py` | Parse the rocprof CSVs (bank conflicts, scratch/spill). |
| `compare-gfx906-q4k-experiment.py`, `compare-gfx906-qwen36.py` | Diff control vs candidate jsonl → report tables. |
| `SCRIPT_compile_MI50.sh`, `SCRIPT_compile_MI50_therock.sh` | Standalone one-shot build scripts (run from repo root). |

All `.sh` resolve repo root via `BASH_SOURCE/../..`, so they work from the
relocated path; build artifacts still land in `<repo>/build/`.

---

## 8. Gotchas (the things that silently waste a run)

1. **The exactly-`gfx906` build gate.** The Q4_K/Q6_K specializations only
   compile when `CMAKE_HIP_ARCHITECTURES` is exactly `gfx906`. A multi-arch build
   (e.g. `gfx906;gfx908`) silently drops them — candidate == control and the run
   is wasted. Verify post-configure: `grep -rl GFX906_PRECOMPUTE build/<dir>`
   must be non-empty. (The Q8_0 patch is a runtime `cc` check, so it survives
   multi-arch builds; the kernel patches do not.)
2. **Stale comparison worktree.** `build/.mainline-src` can be left dirty with a
   patch applied from a prior run. For a clean control, remove and recreate it at
   `origin/master` before building.
3. **Opposite tuning for Q4_K vs Q6_K.** `min_blocks=1` helps Q6_K (+4%) and
   wrecks Q4_K (-34%). Don't port a Q4_K idea to Q6_K or vice-versa without
   re-profiling the bottleneck.
4. **MI50-1 is handicapped** (178 W cap, chipset PCIe) vs MI50-0 (225 W). The two
   cards are not equivalent; don't average them blindly.

---

## 9. Where to pick up

- **Plan of record:** `docs/whatsnext.md` — currently focused on maximizing **TG
  for Q8_0 and Q4_K_M**, starting with a warp-cooperative MMVQ rewrite (Q8_0 has a
  reference in the iacopPBK fork; Q4_K/Q6_K MMVQ are original work).
- **Fresh baseline in progress:** `bench-results/gfx906-head-2026-06-20/` (head
  vs head+patches). Once complete it is the reference both for "did a change help"
  and for the roofline gap that motivates the TG work.
- **Validation still open:** dual-MI50 split-mode benchmark; Q6_K spill trace.

# gfx906 optimization work

Last updated: 2026-06-20

This directory contains private-fork work for AMD Vega 20 GPUs: MI50, MI60,
and Radeon VII. This is the sole operational and technical guide. Measured
results and their confidence levels are recorded in `RESULTS.md`.

The work is for a private fork. Upstream llama.cpp contribution rules still
apply if any part is later proposed upstream.

## Scope

gfx906 has no MFMA matrix cores. Quantized matrix multiplication uses the
vector ALU, principally `V_DOT4_I32_I8` through `ggml_cuda_dp4a`.

This creates two distinct optimization problems:

- Prompt processing (PP or prefill) uses MMQ and is usually limited by DP4A,
  LDS behavior, register pressure, or occupancy.
- Token generation (TG or decode) normally uses MMVQ and is usually limited by
  effective HBM2 bandwidth plus long-context attention and KV-cache traffic.

Do not transfer occupancy conclusions between quant types without profiling.
The accepted Q4_K and Q6_K changes deliberately make opposite tradeoffs.

## Repository layout

The source changes remain in upstream paths because they modify existing code:

- `ggml/src/ggml-cuda/mmq.cu`: selective Q8_0 rocBLAS dispatch
- `ggml/src/ggml-cuda/mmq.cuh`: Q4_K and Q6_K gfx906 specializations
- `ggml/src/ggml-hip/CMakeLists.txt`: exact-gfx906 compile gates

Everything added specifically for this work is under `vr/`:

- `patches/`: standalone source changes and retained experiment patches
- `scripts/`: build, benchmark, comparison, and profiling tools
- `bench-results/`: raw JSONL, text, and profiler output
- `configs/`: server model presets
- `assets/`: benchmark prompt fixtures
- `archive/`: snapshots of superseded documentation

The intended branch delta from upstream is the three scoped source changes plus
the `vr/` tree. New optimization source changes should have a corresponding
standalone patch under `vr/patches/`.

## Accepted source changes

### Q8_0 selective rocBLAS dispatch

For dense Q8_0 matmuls on Vega 20, `ggml_cuda_should_use_mmq` keeps MMQ through
`ne11 <= 256` and uses the existing rocBLAS path above that threshold. Expert
`MUL_MAT_ID` operations remain on MMQ.

The observed benefit is in wide prefill operations. The current evidence does
not establish a decode benefit.

### Q4_K metadata precompute and stride-9 LDS layout

The gfx906 Q4_K MMQ specialization computes final `dm * scale` and `dm * min`
metadata while loading the weight tile instead of repeatedly unpacking it in
the dot-product loop. Metadata rows use stride 9 to reduce LDS bank conflicts
for the existing wave64 geometry.

Profiling showed Q4_K to be LDS-wait and occupancy sensitive. Keeping occupancy
is important. Applying `min_blocks=1` to Q4_K caused a large regression.

### Q6_K minimum launch occupancy of one block

The gfx906 Q6_K MMQ specialization uses `__launch_bounds__(..., 1)`. This gives
the compiler more VGPR headroom at the cost of occupancy. It improved the
profiled Q6_K workload because that kernel was register-spill and VALU limited,
not LDS-wait limited.

The direct scratch trace that proves removal of the previously observed
52-byte-per-thread spill remains an open validation item.

## Critical build gate

The Q4_K and Q6_K specializations compile only when the HIP target list
contains exactly one target and that target is `gfx906`. A multi-architecture build
silently uses the generic implementations. The Q8_0 dispatch uses a runtime
compute-capability check and is not subject to this compile gate.

Configure and build with:

```bash
source vr/scripts/setup-therock-env.sh

cmake -S . -B build/gfx906 \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_HIP_ARCHITECTURES=gfx906 \
  -DGGML_HIP=ON \
  -DGGML_HIP_GRAPHS=ON \
  -DGGML_HIP_NO_VMM=ON \
  -DLLAMA_BUILD_TESTS=ON \
  -DBUILD_SHARED_LIBS=ON

cmake --build build/gfx906 -j --target llama-bench test-backend-ops
```

Verify that the specialization was compiled rather than assuming the CMake
option was honored:

```bash
grep -rl GFX906_PRECOMPUTE build/gfx906
```

## Correctness gate

Run the full ROCm matrix-multiplication tests before accepting any kernel
change:

```bash
build/gfx906/bin/test-backend-ops -b ROCm0 -o MUL_MAT
```

For a new quant-specific implementation, first use a focused test during
development, then run the full gate before recording an accepted result.

## A/B build rules

A valid full-patch comparison is:

- Control: clean selected upstream commit, with no gfx906 patches applied.
- Candidate: the same upstream commit plus the intended patch set.

`vr/scripts/build-gfx906-comparison.sh` currently defaults `CONTROL_PATCH` to
the Q8_0 patch for older incremental comparisons. Therefore, explicitly set an
empty value for a clean control:

```bash
CONTROL_PATCH="" vr/scripts/build-gfx906-comparison.sh
```

This default is a known tooling hazard. A benchmark is not a clean head versus
all-patches comparison unless its provenance confirms that `CONTROL_PATCH` was
empty.

Before a run, also verify that `build/.mainline-src` is at the intended commit
and contains no unexpected changes. Do not silently reuse a dirty comparison
worktree.

## Benchmark policy

Use `-p N -d D` for prompt processing and `-n M -d D` for generation. Do not use
a blended prompt-plus-generation result when evaluating a PP- or TG-specific
change.

The primary harness is `vr/scripts/bench-head.sh`. Its defaults are appropriate
for triage, not acceptance:

- `REPS=1` plus warmup is a fast screening run.
- Any interesting result must be repeated with at least `REPS=5`.
- Small deltas require alternating independent invocations, not only repeated
  samples inside one invocation.
- Control and candidate should be interleaved per test.
- Record clocks, power, and temperatures for bandwidth-sensitive TG work.

The current harness interleaves control and candidate and keeps warmup enabled.
It does not yet write a complete provenance and telemetry manifest. Until that
is added, record the source commits, patch hashes, command-line environment,
and `rocm-smi` state beside each accepted result.

### Single-GPU and dual-GPU measurements

For Q4_K_M, measure both:

- Single GPU with `-sm none -dev ROCm0` for the cleanest kernel baseline.
- Dual GPU with the deployment split mode for end-to-end behavior.

Layer split serializes each token across GPU layer groups and does not simply
sum both cards' bandwidth. Row split can use both cards within a matrix
operation but adds synchronization and PCIe traffic. Benchmark both on this
machine rather than assuming either is better.

Q8_0 does not fit the same long-context single-GPU matrix used by the current
benchmark, so its present end-to-end baseline is dual GPU.

### Thermal and power controls

The two installed cards are not equivalent. MI50-0 has a 225 W cap and direct
CPU PCIe attachment; MI50-1 has a 178 W cap and chipset PCIe attachment. Do not
average them as interchangeable devices.

Measure active memory clock and power before comparing a TG result with a
theoretical 1024 GB/s HBM2 figure. Use measured sustainable bandwidth at the
actual clock as the practical roofline. Any power-limit change requires normal
hardware safety review and should be reported separately from kernel results.

## Current plan

The current focus is stable, measurable TG improvement for Q8_0 and Q4_K_M.
Do not begin a large kernel port until the baseline and configuration gates
below are complete.

1. Establish a reproducible TG baseline.
   - Build a verified clean control and candidate from the same upstream commit.
   - Add or manually capture a provenance manifest.
   - Repeat Q4_K_M single/dual and Q8_0 dual at depth 0, 8192, and 16384 with at
     least five repetitions and clock/power telemetry.
2. Measure configuration-level opportunities.
   - Compare layer and row split on the real dual-MI50 topology.
   - Compare F16 and Q8_0 KV cache at long context, including a quality check.
   - Compare Flash Attention on and off.
   - Evaluate speculative decoding with `llama-server`; `llama-bench` does not
     measure speculative acceptance.
3. Profile the actual decode kernels.
   - Confirm which MMVQ kernels dominate Q8_0 and Q4_K_M generation.
   - Measure effective bandwidth, occupancy, and memory-clock state.
   - Inventory the model's Q4_K and Q6_K tensor bytes before sizing Q6_K work.
4. Evaluate a gfx906 Q8_0 MMVQ port.
   - Use the iacopPBK gfx906 fork only as a design reference.
   - Gate the implementation to gfx906.
   - Require full correctness plus repeated short- and long-context TG gains.
5. Evaluate Q4_K MMVQ only after the Q8_0 port validates the wave64 technique.
6. Evaluate Q6_K MMVQ only if its measured byte share justifies the work.

The practical bandwidth target should be derived from a measured bandwidth
microbenchmark. The previous aspirational target of more than 85 percent of
advertised peak is not an acceptance gate.

## Do not reopen without new evidence

- Q4_K `min_blocks=1`: pp8192 regressed by 33.74 percent.
- Q4_K y64 tile: pp8192 regressed by 9.27 percent.
- Forced Q4_K rocBLAS/F16 conversion: operator-level regression of 30 to 34
  percent.
- Q4_K stride 10 or 11: both lost in the tested configurations.
- Q4_K group2pad1 layout: LDS conflicts returned to the original level.
- Q6_K prefill metadata precompute: pp8192 regressed by 5.3 percent.
- Q5_K `min_blocks=1`: representative n=512 operator throughput regressed by
  about 17 percent.

These conclusions apply to the recorded prefill experiments. They do not by
themselves reject a distinct Q6_K decode MMVQ design.

## Script index

- `setup-therock-env.sh`: configure the TheRock compiler/runtime environment
- `build-gfx906-comparison.sh`: build upstream control and current candidate
- `bench-head.sh`: primary PP/TG A/B harness
- `watch-bench.sh` and `_bench_table.py`: live result display
- `profile-gfx906-q4k-shapes.sh`: rocprof capture
- `analyze-gfx906-q4k-profile.py`: profiler output analysis
- `run-gfx906-q4k-experiment.sh`: staged Q4_K experiment driver
- `bench-q6k-min-blocks-1.sh`: historical Q6_K launch-bound experiment
- `bench-gfx906-rocm-vulkan.sh`: backend comparison

Older scripts may use one repetition with warmup disabled. Their outputs are
historical evidence and should not define the current acceptance policy.

## Documentation archive

The complete pre-consolidation Markdown tree is preserved at:

```text
vr/archive/docs-pre-consolidation-2026-06-20.tar.gz
```

SHA-256:

```text
8dcbf659820e9cac33ba7caae6155d0558cb4544f5ca97a84fbc1f6d3f521c2e
```

List or extract it from the repository root with:

```bash
tar -tzf vr/archive/docs-pre-consolidation-2026-06-20.tar.gz
tar -xzf vr/archive/docs-pre-consolidation-2026-06-20.tar.gz -C /tmp
```

The archive contains the previous guides, benchmark document, optimization
summary, plan, and generated Markdown reports. Raw benchmark and profiler data
remain in their original `vr/bench-results/` locations.

For future material rewrites, create a new dated archive before editing these
two files. Do not replace an existing archive; each archive is a documentation
checkpoint for resolving later discrepancies.
